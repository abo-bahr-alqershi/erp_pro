// Enum مشتق من جدول PricingLevels، الحقل: CostType
public enum CostTypeEnum
{
    Primary = 1,
    Final = 2
}