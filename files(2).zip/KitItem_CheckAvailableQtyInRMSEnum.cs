// Enum مشتق من جدول KitItem، الحقل: CheckAvailableQtyInRMS
public enum CheckAvailableQtyInRMSEnum
{
    No = 0,
    Yes = 1
}