// Enum مشتق من جدول Measurement، الحقل: AllowUpdate
public enum MeasurementAllowUpdateEnum
{
    NotAllowed = 0,
    Allowed = 1
}