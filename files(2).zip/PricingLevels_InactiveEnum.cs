// Enum مشتق من جدول PricingLevels، الحقل: Inactive
public enum PricingLevelInactiveEnum
{
    Active = 0,
    Inactive = 1
}