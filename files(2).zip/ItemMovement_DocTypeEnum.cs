// Enum مشتق من جدول ItemMovement، الحقل: DocType
public enum ItemMovementDocTypeEnum
{
    Sale = 1,
    Return = 2,
    Transfer = 3,
    // أضف حسب النظام
}