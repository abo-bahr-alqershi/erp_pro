// Enum مشتق من جدول WarehouseDetails، الحقل: UseBinMovement
public enum UseBinMovementEnum
{
    No = 0,
    Yes = 1
}