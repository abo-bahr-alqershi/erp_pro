// Enum مشتق من جدول WarehouseDetails، الحقل: WarehouseType
public enum WarehouseTypeEnum
{
    Main = 1,      // رئيسي
    Branch = 2,    // فرعي
    Service = 3    // خدمي
}