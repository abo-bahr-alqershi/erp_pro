// Enum مشتق من جدول CompoundItem، الحقل: Optional
public enum CompoundItemOptionalEnum
{
    No = 0,
    Yes = 1
}