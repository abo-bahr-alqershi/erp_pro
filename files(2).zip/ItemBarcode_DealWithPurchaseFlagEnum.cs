// Enum مشتق من جدول ItemBarcode، الحقل: DealWithPurchaseFlag
public enum DealWithPurchaseFlagEnum
{
    No = 0,
    Yes = 1
}