// Enum مشتق من جدول InventoryAdjustment، الحقل: Hung
public enum InventoryHungEnum
{
    NotHung = 0,
    Hung = 1
}