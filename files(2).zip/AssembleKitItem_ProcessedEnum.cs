// Enum مشتق من جدول AssembleKitItem، الحقل: Processed
public enum AssembleKitItemProcessedEnum
{
    NotProcessed = 0,
    Processed = 1
}