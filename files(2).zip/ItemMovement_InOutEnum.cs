// Enum مشتق من جدول ItemMovement، الحقل: InOut
public enum InOutEnum
{
    In = 1,
    Out = 2
}