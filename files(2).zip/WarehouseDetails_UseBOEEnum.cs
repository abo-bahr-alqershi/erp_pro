// Enum مشتق من جدول WarehouseDetails، الحقل: UseBOE
public enum UseBOEEnum
{
    No = 0,
    Yes = 1
}