// Enum مشتق من جدول InventoryBinDetail، الحقل: ExternalPost
public enum BinExternalPostEnum
{
    No = 0,
    Yes = 1
}