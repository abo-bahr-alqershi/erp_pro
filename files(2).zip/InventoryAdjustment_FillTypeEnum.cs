// Enum مشتق من جدول InventoryAdjustment، الحقل: FillType
public enum FillTypeEnum
{
    Manual = 1,
    Automatic = 2
}