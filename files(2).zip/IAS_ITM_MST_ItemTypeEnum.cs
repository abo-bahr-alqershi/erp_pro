// Enum مشتق من جدول IAS_ITM_MST، الحقل: ItemType
public enum ItemTypeEnum
{
    RawMaterial = 1,
    FinishedProduct = 2,
    Service = 3
    // ... أضف حسب النظام
}