// Enum مشتق من جدول WarehouseDetails، الحقل: ShowWarehouseType
public enum ShowWarehouseTypeEnum
{
    Hide = 0,
    Show = 1
}