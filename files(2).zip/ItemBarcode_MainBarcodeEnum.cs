// Enum مشتق من جدول ItemBarcode، الحقل: MainBarcode
public enum MainBarcodeEnum
{
    No = 0,
    Yes = 1
}