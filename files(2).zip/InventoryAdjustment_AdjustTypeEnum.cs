// Enum مشتق من جدول InventoryAdjustment، الحقل: AdjustType
public enum AdjustTypeEnum
{
    Periodic = 1,
    Sudden = 2
    // ... أضف حسب النظام
}