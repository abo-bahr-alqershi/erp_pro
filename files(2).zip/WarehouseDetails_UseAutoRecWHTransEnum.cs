// Enum مشتق من جدول WarehouseDetails، الحقل: UseAutoRecWHTrans
public enum UseAutoRecWHTransEnum
{
    No = 0,
    Yes = 1
}