// Enum مشتق من جدول WarehouseDetails، الحقل: ForDamagedItem
public enum ForDamagedItemEnum
{
    No = 0,
    Yes = 1
}