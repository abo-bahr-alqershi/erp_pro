// Enum مشتق من جدول ItemPriceHistory، الحقل: AuditType
public enum AuditTypeEnum
{
    Add = 1,
    Update = 2
}