// Enum مشتق من جدول WarehouseDetails، الحقل: NoSale
public enum NoSaleEnum
{
    AllowSale = 0,
    PreventSale = 1
}