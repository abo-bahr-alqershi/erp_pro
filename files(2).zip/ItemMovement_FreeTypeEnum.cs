// Enum مشتق من جدول ItemMovement، الحقل: FreeType
public enum FreeTypeEnum
{
    None = 0,
    Partial = 1,
    Full = 2
}