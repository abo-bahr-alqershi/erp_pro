// Enum مشتق من جدول WarehouseDetails، الحقل: Inactive
public enum InactiveEnum
{
    Active = 0,
    Inactive = 1
}