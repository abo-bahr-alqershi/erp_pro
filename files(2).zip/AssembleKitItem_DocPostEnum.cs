// Enum مشتق من جدول AssembleKitItem، الحقل: DocPost
public enum AssembleKitItemDocPostEnum
{
    NotPosted = 0,
    Posted = 1
}