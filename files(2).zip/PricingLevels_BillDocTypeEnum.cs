// Enum مشتق من جدول PricingLevels، الحقل: BillDocType
public enum BillDocTypeEnum
{
    Sale = 1,
    Return = 2,
    Transfer = 3,
    // ... أضف حسب النظام
}