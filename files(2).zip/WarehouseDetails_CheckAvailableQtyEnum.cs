// Enum مشتق من جدول WarehouseDetails، الحقل: CheckAvailableQty
public enum CheckAvailableQtyEnum
{
    No = 0,
    Yes = 1
}