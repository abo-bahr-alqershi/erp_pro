// Enum مشتق من جدول ItemMovement، الحقل: ReturnType
public enum ReturnTypeEnum
{
    None = 0,
    Partial = 1,
    Full = 2
}