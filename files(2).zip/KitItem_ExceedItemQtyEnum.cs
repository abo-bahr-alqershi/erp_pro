// Enum مشتق من جدول KitItem، الحقل: ExceedItemQty
public enum ExceedItemQtyEnum
{
    NotAllowed = 0,
    Allowed = 1
}