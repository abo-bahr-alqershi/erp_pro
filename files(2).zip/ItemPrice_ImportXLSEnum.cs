// Enum مشتق من جدول ItemPrice، الحقل: ImportXLS
public enum ImportXLSEnum
{
    No = 0,
    Yes = 1
}