// Enum مشتق من جدول DisassembleKitItem، الحقل: Hung
public enum DisassembleKitItemHungEnum
{
    NotHung = 0,
    Hung = 1
}