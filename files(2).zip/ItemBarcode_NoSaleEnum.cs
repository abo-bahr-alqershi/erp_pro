// Enum مشتق من جدول ItemBarcode، الحقل: NoSale
public enum ItemBarcodeNoSaleEnum
{
    AllowSale = 0,
    PreventSale = 1
}