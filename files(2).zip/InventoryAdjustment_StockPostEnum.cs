// Enum مشتق من جدول InventoryAdjustment، الحقل: StockPost
public enum StockPostEnum
{
    NotPosted = 0,
    Posted = 1
}