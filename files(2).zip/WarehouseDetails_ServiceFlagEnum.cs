// Enum مشتق من جدول WarehouseDetails، الحقل: ServiceFlag
public enum ServiceFlagEnum
{
    NotService = 0,
    Service = 1
}