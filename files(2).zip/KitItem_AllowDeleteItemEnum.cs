// Enum مشتق من جدول KitItem، الحقل: AllowDeleteItem
public enum AllowDeleteItemEnum
{
    NotAllowed = 0,
    Allowed = 1
}