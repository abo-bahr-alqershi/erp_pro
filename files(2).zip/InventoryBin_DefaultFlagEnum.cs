// Enum مشتق من جدول InventoryBin، الحقل: DefaultFlag
public enum InventoryBinDefaultFlagEnum
{
    NotDefault = 0,
    Default = 1
}