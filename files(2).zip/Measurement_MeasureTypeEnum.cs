// Enum مشتق من جدول Measurement، الحقل: MeasureType
public enum MeasureTypeEnum
{
    Unit = 1,
    Weight = 2,
    // ... حسب النظام
}