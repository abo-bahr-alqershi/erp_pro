// Enum مشتق من جدول DisassembleKitItem، الحقل: DocPost
public enum DisassembleKitItemDocPostEnum
{
    NotPosted = 0,
    Posted = 1
}