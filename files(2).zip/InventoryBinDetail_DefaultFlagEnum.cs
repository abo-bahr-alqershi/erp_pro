// Enum مشتق من جدول InventoryBinDetail، الحقل: DefaultFlag
public enum BinDefaultFlagEnum
{
    NotDefault = 0,
    Default = 1
}