// Enum مشتق من جدول InventoryAdjustment، الحقل: StockType
public enum StockTypeEnum
{
    Main = 1,
    Branch = 2,
    Service = 3
}