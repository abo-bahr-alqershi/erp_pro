// Enum مشتق من جدول WarehouseDetails، الحقل: UsePropFlag
public enum UsePropFlagEnum
{
    No = 0,
    Yes = 1
}