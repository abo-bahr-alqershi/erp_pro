// Enum مشتق من جدول AssembleKitItem، الحقل: Hung
public enum AssembleKitItemHungEnum
{
    NotHung = 0,
    Hung = 1
}