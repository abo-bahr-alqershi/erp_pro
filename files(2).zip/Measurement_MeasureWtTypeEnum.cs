// Enum مشتق من جدول Measurement، الحقل: MeasureWtType
public enum MeasureWtTypeEnum
{
    None = 0,
    Weight = 1,
    Volume = 2
}