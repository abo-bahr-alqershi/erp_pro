// Enum مشتق من جدول PricingLevels، الحقل: LevelDefault
public enum LevelDefaultEnum
{
    No = 0,
    Yes = 1
}