// Enum مشتق من جدول ItemBarcode، الحقل: NoPrint
public enum NoPrintEnum
{
    AllowPrint = 0,
    PreventPrint = 1
}